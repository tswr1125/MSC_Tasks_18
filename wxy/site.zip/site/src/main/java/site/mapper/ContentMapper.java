package site.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import site.dao.ContentDAO;

@Mapper
public interface ContentMapper
{
    ContentDAO getContentByName(String name);
    
    List<ContentDAO> getContentsByDisplayMethod(String displayMethod);
    
    List<ContentDAO> getContentsByDisplayLevel(String displayLevel);
}
