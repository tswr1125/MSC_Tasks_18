package site.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;

public class FileReader
{
    private FileReader()
    {
    }

    public static String read(String path)
    {
        InputStream in = null;
        BufferedReader br = null;
        StringBuffer sb = null;
        try
        {
            in = new FileInputStream(path);
            br = new BufferedReader(new InputStreamReader(in));
            sb = new StringBuffer();
            String tmp;
            while ((tmp = br.readLine()) != null)
            {
                sb.append(tmp + "\n");
            }
            in.close();
            br.close();
            return sb.toString();
        } catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
    }
}
