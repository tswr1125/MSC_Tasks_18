package site.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import site.service.ContentService;
import site.service.GeneralService;

@Controller
public class PageController
{
    @Autowired
    private GeneralService generalService;
    
    @RequestMapping("/")
    public String root()
    {
        return "redirect:index";
    }
    
    @RequestMapping("{name}")
    public ModelAndView content(@PathVariable String name)
    {
        ContentService contentService = generalService.getContentService(name);
        if (contentService == null)
        {
            return new ModelAndView("error/404");
        }
        ModelAndView mav = new ModelAndView(contentService.getTemplate());
        mav.addObject("general", generalService.getGeneral());
        mav.addObject("content", contentService.getContent(name));
        return mav;
    }
}
