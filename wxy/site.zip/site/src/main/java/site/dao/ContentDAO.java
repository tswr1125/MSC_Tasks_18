package site.dao;

public class ContentDAO
{
    private String name;
    private String title;
    private String introduction;
    private String image;
    private String displayMethod;
    private String displayLevel;
    private String category;
    private String url;

    public ContentDAO()
    {
        this("", "", "", "", "", "", "", "");
    }

    public ContentDAO(
                    String name, String title, String introduction, String image, String displayMethod,
                    String displayLevel, String category, String url
    )
    {
        this.setName(name);
        this.setTitle(title);
        this.setIntroduction(introduction);
        this.setImage(image);
        this.setDisplayMethod(displayMethod);
        this.setDisplayLevel(displayLevel);
        this.setCategory(category);
        this.setUrl(url);
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getIntroduction()
    {
        return introduction;
    }

    public void setIntroduction(String introduction)
    {
        this.introduction = introduction;
    }

    public String getImage()
    {
        return image;
    }

    public void setImage(String image)
    {
        this.image = image;
    }

    public String getDisplayMethod()
    {
        return displayMethod;
    }

    public void setDisplayMethod(String displayMethod)
    {
        this.displayMethod = displayMethod;
    }

    public String getDisplayLevel()
    {
        return displayLevel;
    }

    public void setDisplayLevel(String displayLevel)
    {
        this.displayLevel = displayLevel;
    }

    public String getCategory()
    {
        return category;
    }

    public void setCategory(String category)
    {
        this.category = category;
    }

    public String getUrl()
    {
        return url;
    }

    public void setUrl(String url)
    {
        this.url = url;
    }
}
