package site.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import site.dao.ContentDAO;
import site.entity.General;
import site.mapper.ContentMapper;
import site.mapper.PropertiesMapper;
import site.service.content.IndexService;
import site.service.content.MarkdownService;
import site.service.content.RawHtmlService;

@Service
public class GeneralService
{
    @Autowired
    private PropertiesMapper propertiesMapper;

    @Autowired
    private ContentMapper    contentMapper;

    @Autowired
    private RawHtmlService   rawHtmlService;

    @Autowired
    private IndexService     indexService;

    @Autowired
    private MarkdownService  markdownService;

    public GeneralService()
    {
    }

    public ContentService getContentService(String name)
    {
        switch (contentMapper.getContentByName(name).getDisplayMethod())
        {
        case "rawhtml":
            return rawHtmlService;
        case "index":
            return indexService;
        case "markdown":
            return markdownService;
        default:
            return null;
        }
    }

    public General getGeneral()
    {
        General general = new General();
        general.setPageTitle(propertiesMapper.getValueByName("pageTitle"));
        general.setNavbarTitle(propertiesMapper.getValueByName("navbarTitle"));
        Map<String, String> navbarUrl = new HashMap<String, String>();
        List<ContentDAO> daos = contentMapper.getContentsByDisplayLevel("navbar");
        for (ContentDAO dao : daos)
        {
            navbarUrl.put(dao.getTitle(), dao.getUrl());
        }
        general.setNavbarUrls(navbarUrl);
        general.setIntroductionTitle(propertiesMapper.getValueByName("introductionTitle"));
        general.setIntroductionImage(propertiesMapper.getValueByName("introductionImage"));
        general.setIntroductionText(propertiesMapper.getValueByName("introductionText"));
        general.setExtraLinkTitle(propertiesMapper.getValueByName("extraLinkTitle"));
        Map<String, String> extraLinkUrl = new HashMap<String, String>();
        daos = contentMapper.getContentsByDisplayMethod("link");
        for (ContentDAO dao : daos)
        {
            extraLinkUrl.put(dao.getTitle(), dao.getUrl());
        }
        general.setExtraLinkUrls(extraLinkUrl);
        general.setBottomTitle(propertiesMapper.getValueByName("bottomTitle"));
        return general;
    }
}
