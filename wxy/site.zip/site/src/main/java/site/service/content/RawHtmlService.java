package site.service.content;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import site.dao.ContentDAO;
import site.mapper.ContentMapper;
import site.service.ContentService;
import site.util.FileReader;

@Service
public class RawHtmlService implements ContentService
{
    @Autowired
    private ContentMapper contentMapper;

    @Value("${doc-path}")
    private String        documentPath;

    public RawHtmlService()
    {
    }

    @Override
    public String getContent(String name)
    {
        ContentDAO dao = contentMapper.getContentByName(name);
        return FileReader.read(documentPath + dao.getUrl());
    }

    @Override
    public String getTemplate()
    {
        return "rawhtml";
    }
}
