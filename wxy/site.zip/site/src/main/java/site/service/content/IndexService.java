package site.service.content;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import site.dao.ContentDAO;
import site.entity.ContentAbstract;
import site.mapper.ContentMapper;
import site.service.ContentService;

@Service
public class IndexService implements ContentService
{
    @Autowired
    private ContentMapper contentMapper;

    @Override
    public List<ContentAbstract> getContent(String name)
    {
        List<ContentDAO> daos = contentMapper.getContentsByDisplayLevel("index");
        List<ContentAbstract> content = new ArrayList<ContentAbstract>();
        String category = contentMapper.getContentByName(name).getUrl();
        for (ContentDAO dao : daos)
        {
            if (category.length() == 0 && dao.getCategory().contains(category + ";"))
            {
                content.add(new ContentAbstract(dao.getTitle(), dao.getIntroduction(), dao.getImage(), dao.getName()));
            }
        }
        return content;
    }

    @Override
    public String getTemplate()
    {
        return "index";
    }
}
