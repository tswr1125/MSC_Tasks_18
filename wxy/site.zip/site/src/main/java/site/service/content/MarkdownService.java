package site.service.content;

import org.pegdown.PegDownProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import site.dao.ContentDAO;
import site.mapper.ContentMapper;
import site.service.ContentService;
import site.util.FileReader;

@Service
public class MarkdownService implements ContentService
{
    @Autowired
    private ContentMapper contentMapper;

    @Value("${doc-path}")
    private String        documentPath;

    public MarkdownService()
    {
    }

    @Override
    public String getContent(String name)
    {
        ContentDAO dao = contentMapper.getContentByName(name);
        String md = FileReader.read(documentPath + dao.getUrl());
        PegDownProcessor pdp = new PegDownProcessor(Integer.MAX_VALUE);
        return pdp.markdownToHtml(md);
    }

    @Override
    public String getTemplate()
    {
        return "markdown";
    }
}
