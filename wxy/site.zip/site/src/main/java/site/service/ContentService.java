package site.service;

public interface ContentService
{
    Object getContent(String name);
    
    String getTemplate();
}
