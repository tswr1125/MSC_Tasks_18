package site.entity;

import java.util.Map;

public class General
{
    private String              pageTitle;
    private String              navbarTitle;
    private Map<String, String> navbarUrls;
    private String              introductionTitle;
    private String              introductionImage;
    private String              introductionText;
    private String              extraLinkTitle;
    private Map<String, String> extraLinkUrls;
    private String              bottomTitle;

    public General()
    {
    }

    public String getPageTitle()
    {
        return pageTitle;
    }

    public void setPageTitle(String pageTitle)
    {
        this.pageTitle = pageTitle;
    }

    public String getNavbarTitle()
    {
        return navbarTitle;
    }

    public void setNavbarTitle(String navbarTitle)
    {
        this.navbarTitle = navbarTitle;
    }

    public Map<String, String> getNavbarUrls()
    {
        return navbarUrls;
    }

    public void setNavbarUrls(Map<String, String> navbarUrls)
    {
        this.navbarUrls = navbarUrls;
    }

    public String getIntroductionTitle()
    {
        return introductionTitle;
    }

    public void setIntroductionTitle(String introductionTitle)
    {
        this.introductionTitle = introductionTitle;
    }

    public String getIntroductionImage()
    {
        return introductionImage;
    }

    public void setIntroductionImage(String introductionImage)
    {
        this.introductionImage = introductionImage;
    }

    public String getIntroductionText()
    {
        return introductionText;
    }

    public void setIntroductionText(String introductionText)
    {
        this.introductionText = introductionText;
    }

    public String getExtraLinkTitle()
    {
        return extraLinkTitle;
    }

    public void setExtraLinkTitle(String extraLinkTitle)
    {
        this.extraLinkTitle = extraLinkTitle;
    }

    public Map<String, String> getExtraLinkUrls()
    {
        return extraLinkUrls;
    }

    public void setExtraLinkUrls(Map<String, String> extraLinkUrls)
    {
        this.extraLinkUrls = extraLinkUrls;
    }

    public String getBottomTitle()
    {
        return bottomTitle;
    }

    public void setBottomTitle(String bottomTitle)
    {
        this.bottomTitle = bottomTitle;
    }
}
