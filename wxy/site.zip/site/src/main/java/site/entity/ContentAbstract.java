package site.entity;

public class ContentAbstract
{
    private String title;
    private String introduction;
    private String image;
    private String url;
    
    public ContentAbstract()
    {
        this("", "", "", "");
    }
    
    public ContentAbstract(String title, String introduction, String image, String url)
    {
        this.setTitle(title);
        this.setIntroduction(introduction);
        this.setImage(image);
        this.setUrl(url);
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getIntroduction()
    {
        return introduction;
    }

    public void setIntroduction(String introduction)
    {
        this.introduction = introduction;
    }

    public String getImage()
    {
        return image;
    }

    public void setImage(String image)
    {
        this.image = image;
    }
    
    public String getUrl()
    {
        return url;
    }
    
    public void setUrl(String url)
    {
        this.url = url;
    }
}
